
import os, argparse, json, joblib, numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score

HERE = os.path.dirname(__file__)

def load_or_synthesize(cfg: dict, use_real: bool):
    def safe_read(path, cols):
        if os.path.exists(path):
            df = pd.read_csv(path)
            missing = [c for c in cols if c not in df.columns]
            if missing:
                raise ValueError(f"Missing columns {missing} in {path}")
            return df[cols]
        else:
            return None

    if use_real:
        v = safe_read(os.path.join(HERE, cfg["audio_csv"]), ["pitch","jitter","shimmer","is_threat"])
        m = safe_read(os.path.join(HERE, cfg["motion_csv"]), ["acc_mean","acc_std","jerk","is_threat"])
        s = safe_read(os.path.join(HERE, cfg["sentiment_csv"]), ["sentiment_score","is_threat"])
        parts = [d for d in [v,m,s] if d is not None]
        if not parts:
            raise FileNotFoundError("No real CSVs found. Put them in data/ or run without --use-real to synthesize.")
    else:
        # Synthetic demo data
        n = 2000
        rng = np.random.default_rng(42)
        v = pd.DataFrame({
            "pitch": rng.normal(220, 60, n),
            "jitter": rng.normal(0.02, 0.01, n).clip(0, 0.2),
            "shimmer": rng.normal(0.15, 0.05, n).clip(0, 1),
            "is_threat": (rng.random(n) < 0.3).astype(int)
        })
        m = pd.DataFrame({
            "acc_mean": rng.normal(0.1, 0.2, n),
            "acc_std": rng.normal(1.0, 0.3, n).clip(0, 5),
            "jerk": rng.normal(1.0, 0.7, n).clip(0, 5),
            "is_threat": (rng.random(n) < 0.3).astype(int)
        })
        s = pd.DataFrame({
            "sentiment_score": rng.normal(0.0, 0.6, n).clip(-1, 1),
            "is_threat": (rng.random(n) < 0.3).astype(int)
        })
        parts = [v,m,s]

    # Merge by sampling equal-length index
    length = min(len(p) for p in parts)
    parts = [p.sample(length, random_state=0).reset_index(drop=True) for p in parts]
    X = pd.concat([p.drop(columns=["is_threat"]) for p in parts], axis=1)
    # Majority vote to derive label for synthetic merge; with real data, align by record ID instead
    y = pd.DataFrame({"y": np.mean([p["is_threat"] for p in parts], axis=0)})
    y = (y["y"] >= 0.5).astype(int)

    return X, y

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.json"))
    ap.add_argument("--use-real", action="store_true", help="Train on CSVs in data/ instead of synthetic sample")
    args = ap.parse_args()

    with open(args.config, "r") as f:
        cfg = json.load(f)

    X, y = load_or_synthesize(cfg, args.use_real)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    clf = RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced")
    clf.fit(X_train, y_train)
    preds = clf.predict(X_test)
    proba = clf.predict_proba(X_test)[:,1]

    print(classification_report(y_test, preds))
    try:
        print("ROC-AUC:", roc_auc_score(y_test, proba))
    except Exception:
        pass

    out_path = os.path.normpath(os.path.join(HERE, cfg["output_model"]))
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    joblib.dump(clf, out_path)
    print("Saved model to", out_path)

if __name__ == "__main__":
    main()
