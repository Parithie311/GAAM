
# Datasets (plug in here later)

Recommended public datasets:
- **Voice emotion**: RAVDESS, CREMA-D (extract features like pitch/jitter/shimmer or MFCCs)
- **Motion/Activity**: UCI HAR Dataset (accelerometer/gyroscope), WISDM
- **Sentiment**: Sentiment140, GoEmotions

How to use:
1. Convert raw sources to **tabular feature CSVs** matching these schemas:
   - `voice_features.csv`: columns = [pitch, jitter, shimmer, is_threat]
   - `motion_features.csv`: columns = [acc_mean, acc_std, jerk, is_threat]
   - `sentiment_features.csv`: columns = [sentiment_score, is_threat]
2. Place CSVs in `data/` and update paths in `config.json` if needed.
3. Run `python train_threat_model.py --use-real` to train on your data.
