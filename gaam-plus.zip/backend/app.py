
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import numpy as np
import pandas as pd
import os, io, time, joblib

APP_DIR = os.path.dirname(__file__)
MODEL_PATH = os.path.join(APP_DIR, "models", "threat_model.pkl")
EVIDENCE_DIR = os.path.join(APP_DIR, "evidence")
ALERTS_LOG = os.path.join(APP_DIR, "data", "alerts.csv")
os.makedirs(EVIDENCE_DIR, exist_ok=True)
os.makedirs(os.path.join(APP_DIR, "data"), exist_ok=True)

app = FastAPI(title="GAAM+ Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class SensorPacket(BaseModel):
    # Minimal unified packet (extend as needed)
    timestamp: float
    # Voice features
    pitch: float | None = None
    jitter: float | None = None
    shimmer: float | None = None
    # Motion (accelerometer-derived features)
    acc_mean: float | None = None
    acc_std: float | None = None
    jerk: float | None = None
    # Sentiment (from on-device NLP or server NLP)
    sentiment_score: float | None = None
    # Location
    lat: float | None = None
    lon: float | None = None

def load_model():
    if os.path.exists(MODEL_PATH):
        try:
            return joblib.load(MODEL_PATH)
        except Exception:
            return None
    return None

model = load_model()

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": bool(model)}

@app.post("/predict-threat")
def predict_threat(packet: SensorPacket):
    # If model exists, use it; else use a simple heuristic fallback.
    feats = [
        packet.pitch or 0.0,
        packet.jitter or 0.0,
        packet.shimmer or 0.0,
        packet.acc_mean or 0.0,
        packet.acc_std or 0.0,
        packet.jerk or 0.0,
        packet.sentiment_score or 0.0,
    ]
    x = np.array(feats).reshape(1, -1)

    if model is not None:
        prob = float(model.predict_proba(x)[0, 1])
        label = int(prob >= 0.5)
    else:
        # Heuristic scoring
        score = 0.0
        score += (packet.pitch or 0) > 300
        score += (packet.jerk or 0) > 2.0
        score += (packet.sentiment_score or 0) < -0.3
        prob = min(1.0, score / 3.0)
        label = int(prob >= 0.5)

    # Optionally auto-log alerts for dashboard
    if (packet.lat is not None) and (packet.lon is not None):
        ensure_alerts_log()
        append_alert(packet.lat, packet.lon, prob)

    return {"threat_probability": prob, "threat_label": label}

def ensure_alerts_log():
    if not os.path.exists(ALERTS_LOG):
        import csv
        with open(ALERTS_LOG, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["timestamp", "lat", "lon", "probability"])

def append_alert(lat: float, lon: float, p: float):
    import csv, time
    with open(ALERTS_LOG, "a", newline="") as f:
        w = csv.writer(f)
        w.writerow([time.time(), lat, lon, p])

@app.post("/sos")
def sos(name: str = Form(...), phone: str = Form(...), lat: float = Form(None), lon: float = Form(None)):
    # In a real system, integrate with SMS/gov APIs.
    ensure_alerts_log()
    if (lat is not None) and (lon is not None):
        append_alert(lat, lon, 1.0)
    return {"status": "SOS sent", "to_contacts": True, "mock": True}

@app.post("/upload-evidence")
async def upload_evidence(file: UploadFile = File(...), note: str = Form(None)):
    content = await file.read()
    fname = f"{int(time.time())}_{file.filename}"
    path = os.path.join(EVIDENCE_DIR, fname)
    with open(path, "wb") as f:
        f.write(content)
    return {"status": "saved", "file": fname, "bytes": len(content), "note": note}

@app.get("/hotspots")
def hotspots(limit: int = 1000):
    if not os.path.exists(ALERTS_LOG):
        return {"hotspots": []}
    df = pd.read_csv(ALERTS_LOG)
    df = df.tail(limit)
    points = df[["lat", "lon", "probability"]].dropna().values.tolist()
    return {"hotspots": points}
