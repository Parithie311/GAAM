
import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="GAAM+ Safety Dashboard")

st.title("GAAM+ Safety Dashboard")
st.write("Hotspot heatmap from recent alerts (demo). Replace data/alerts.csv in production.")

@st.cache_data
def load_data():
    return pd.read_csv("data/alerts.csv")

df = load_data()
if df.empty:
    st.warning("No alerts yet.")
else:
    center = [df["lat"].mean(), df["lon"].mean()]
    m = folium.Map(location=center, zoom_start=6)
    for _, row in df.iterrows():
        popup = f"p={row['probability']:.2f}"
        folium.CircleMarker([row["lat"], row["lon"]], radius=6, popup=popup).add_to(m)
    st_folium(m, width=700, height=500)

st.write("Records:", len(df))
st.dataframe(df.tail(50))
