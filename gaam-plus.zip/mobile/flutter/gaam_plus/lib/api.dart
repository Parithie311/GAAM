
import 'dart:convert';
import 'package:http/http.dart' as http;

class Api {
  // For Android emulator use http://10.0.2.2:8000; iOS simulator http://127.0.0.1:8000
  static String base = const String.fromEnvironment('GAAM_API', defaultValue: 'http://10.0.2.2:8000');

  static Future<bool> health() async {
    try {
      final r = await http.get(Uri.parse('$base/health'));
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  static Future<double> predictThreat() async {
    final payload = {
      "timestamp": DateTime.now().millisecondsSinceEpoch / 1000.0,
      "pitch": 330.0,
      "jitter": 0.03,
      "shimmer": 0.18,
      "acc_mean": 0.1,
      "acc_std": 1.4,
      "jerk": 2.5,
      "sentiment_score": -0.6,
      "lat": 13.0827,
      "lon": 80.2707
    };
    final r = await http.post(Uri.parse('$base/predict-threat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload));
    final j = jsonDecode(r.body);
    return (j['threat_probability'] ?? 0.0) * 1.0;
  }

  static Future<Map<String, dynamic>> sos({required String name, required String phone, double? lat, double? lon}) async {
    final req = http.MultipartRequest('POST', Uri.parse('$base/sos'));
    req.fields['name'] = name;
    req.fields['phone'] = phone;
    if (lat != null) req.fields['lat'] = lat.toString();
    if (lon != null) req.fields['lon'] = lon.toString();
    final streamed = await req.send();
    final r = await http.Response.fromStream(streamed);
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}
