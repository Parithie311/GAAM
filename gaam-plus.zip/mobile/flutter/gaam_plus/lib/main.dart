
import 'package:flutter/material.dart';
import 'api.dart';

void main() {
  runApp(const GAAMApp());
}

class GAAMApp extends StatelessWidget {
  const GAAMApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GAAM+',
      theme: ThemeData(useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String status = "Idle";

  Future<void> _checkHealth() async {
    setState(() => status = "Checking backend...");
    final ok = await Api.health();
    setState(() => status = ok ? "Backend OK" : "Backend DOWN");
  }

  Future<void> _sendSOS() async {
    setState(() => status = "Sending SOS...");
    final res = await Api.sos(name: "User", phone: "9999999999", lat: 13.0827, lon: 80.2707);
    setState(() => status = "SOS sent: ${res['status']}");
  }

  Future<void> _predict() async {
    setState(() => status = "Predicting...");
    final p = await Api.predictThreat();
    setState(() => status = "Threat p=${p.toStringAsFixed(2)}");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("GAAM+")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text("Status: $status"),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _checkHealth, child: const Text("Check Backend")),
            ElevatedButton(onPressed: _predict, child: const Text("Predict Threat (demo)")),
            ElevatedButton(onPressed: _sendSOS, child: const Text("Send SOS (demo)")),
            const Spacer(),
            const Text("Tip: set backend URL in lib/api.dart"),
          ],
        ),
      ),
    );
  }
}
